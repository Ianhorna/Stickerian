package com.stickerlab.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final int REQ_FILE = 100;
    static final int REQ_WHATSAPP = 200;
    static final String HOST = "appassets.androidplatform.net";

    WebView web;
    NativeBridge bridge;
    ValueCallback<Uri[]> fileCallback;
    boolean pageLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF14111F);
        web = new WebView(this);
        web.setBackgroundColor(0xFF14111F);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Android 15+ dibuja de borde a borde: dejamos espacio para barras del sistema y teclado
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                notifyShared();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;

                List<String> types = new ArrayList<>();
                String[] accept = params.getAcceptTypes();
                if (accept != null) {
                    for (String a : accept) {
                        if (a == null) continue;
                        for (String t : a.split(",")) {
                            t = t.trim();
                            if (!t.isEmpty()) types.add(t);
                        }
                    }
                }
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                if (types.size() == 1) {
                    i.setType(types.get(0));
                } else {
                    i.setType("*/*");
                    if (!types.isEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
                }
                try {
                    startActivityForResult(i, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        bridge = new NativeBridge(this, web);
        web.addJavascriptInterface(bridge, "Android");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("https://" + HOST + "/assets/index.html");
        }
        handleShareIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
    }

    /** Lee las imágenes que otra app (o la web) compartió con StickerLab. */
    void handleShareIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_SEND_MULTIPLE.equals(action)) return;
        final List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else {
            ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (list != null) uris.addAll(list);
        }
        ClipData clip = intent.getClipData();
        if (uris.isEmpty() && clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri u = clip.getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        }
        // evita reprocesar al rotar la pantalla
        intent.setAction(Intent.ACTION_MAIN);
        if (uris.isEmpty()) return;
        new Thread(() -> {
            int count = 0;
            for (Uri u : uris) {
                if (count >= 30) break;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    if (in == null) continue;
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[65536];
                    int n;
                    int total = 0;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > 25 * 1024 * 1024) break;
                        bo.write(buf, 0, n);
                    }
                    if (total > 25 * 1024 * 1024) continue;
                    String mime = getContentResolver().getType(u);
                    JSONObject o = new JSONObject();
                    o.put("mime", mime == null ? "" : mime);
                    o.put("b64", android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP));
                    bridge.addShared(o.toString());
                    count++;
                } catch (Exception ignored) {
                }
            }
            runOnUiThread(this::notifyShared);
        }).start();
    }

    void notifyShared() {
        if (pageLoaded && bridge.sharedCount() > 0) {
            web.evaluateJavascript("window.__sharedReady && __sharedReady()", null);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    /** Abre la pantalla de WhatsApp para añadir el paquete. */
    void addPackToWhatsApp(String packId, String packName, String targetPackage) {
        Intent i = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
        if (targetPackage != null && !targetPackage.isEmpty()) i.setPackage(targetPackage);
        i.putExtra("sticker_pack_id", packId);
        i.putExtra("sticker_pack_authority", getPackageName() + ".stickercontentprovider");
        i.putExtra("sticker_pack_name", packName);
        try {
            startActivityForResult(i, REQ_WHATSAPP);
        } catch (ActivityNotFoundException e) {
            bridge.toast("No se encontró WhatsApp instalado en este teléfono");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
        } else if (requestCode == REQ_WHATSAPP) {
            if (resultCode == RESULT_OK) {
                bridge.toast("¡Paquete añadido a WhatsApp! 🎉");
            } else if (data != null && data.getStringExtra("validation_error") != null) {
                bridge.toast("WhatsApp rechazó el paquete: " + data.getStringExtra("validation_error"));
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.nativeBack && nativeBack()) ? '1' : '0'", value -> {
            if (value == null || !value.contains("1")) finish();
        });
    }
}
