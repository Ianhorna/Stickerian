package com.stickerlab.app;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Funciones nativas que la página puede llamar como window.Android.* */
public class NativeBridge {

    private final MainActivity act;
    private final WebView web;

    NativeBridge(MainActivity act, WebView web) {
        this.act = act;
        this.web = web;
    }

    void js(String code) {
        act.runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    void toast(String msg) {
        js("window.nativeToast && nativeToast(" + JSONObject.quote(msg) + ")");
    }

    // ---------- Archivos compartidos hacia la app ----------
    private final List<String> shared = new ArrayList<>();

    synchronized void addShared(String json) {
        shared.add(json);
    }

    @JavascriptInterface
    public synchronized int sharedCount() {
        return shared.size();
    }

    @JavascriptInterface
    public synchronized String sharedItem(int i) {
        return (i >= 0 && i < shared.size()) ? shared.get(i) : "{}";
    }

    @JavascriptInterface
    public synchronized void sharedClear() {
        shared.clear();
    }

    // ---------- WhatsApp instalados ----------
    @JavascriptInterface
    public String waApps() {
        JSONArray a = new JSONArray();
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            try {
                act.getPackageManager().getPackageInfo(pkg, 0);
                a.put(pkg);
            } catch (Exception ignored) {
            }
        }
        return a.toString();
    }

    @JavascriptInterface
    public boolean hasAiBg() {
        return true;
    }

    @JavascriptInterface
    public String version() {
        return BuildConfig.VERSION_NAME;
    }

    // ---------- Guardar archivos en la galería / descargas ----------

    static String mimeFor(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    @JavascriptInterface
    public String saveFile(String name, String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            String safe = name.replaceAll("[^A-Za-z0-9_.-]", "_");
            String mime = mimeFor(safe);
            boolean image = mime.startsWith("image/");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/StickerLab");
                Uri collection = image
                        ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri uri = act.getContentResolver().insert(collection, v);
                if (uri == null) return "";
                try (OutputStream os = act.getContentResolver().openOutputStream(uri)) {
                    if (os == null) return "";
                    os.write(data);
                }
                return (image ? "Imágenes" : "Descargas") + "/StickerLab/" + safe;
            } else {
                File dir = new File(act.getExternalFilesDir(null), "StickerLab");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File f = new File(dir, safe);
                try (FileOutputStream fo = new FileOutputStream(f)) {
                    fo.write(data);
                }
                return f.getAbsolutePath();
            }
        } catch (Throwable e) {
            return "";
        }
    }

    // ---------- Quitar fondo con IA (ML Kit, en el teléfono) ----------

    @JavascriptInterface
    public void removeBg(final String reqId, String b64) {
        try {
            byte[] d = Base64.decode(b64, Base64.DEFAULT);
            Bitmap bmp = BitmapFactory.decodeByteArray(d, 0, d.length);
            if (bmp == null) {
                bgResult(reqId, "", "No se pudo leer la imagen");
                return;
            }
            SubjectSegmenterOptions opts = new SubjectSegmenterOptions.Builder()
                    .enableForegroundBitmap()
                    .build();
            final SubjectSegmenter seg = SubjectSegmentation.getClient(opts);
            seg.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener(result -> {
                        Bitmap fg = result.getForegroundBitmap();
                        if (fg == null) {
                            bgResult(reqId, "", "No se detectó a nadie ni ningún objeto en la foto");
                        } else {
                            ByteArrayOutputStream bo = new ByteArrayOutputStream();
                            fg.compress(Bitmap.CompressFormat.PNG, 100, bo);
                            bgResult(reqId, Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP), "");
                        }
                        closeQuietly(seg);
                    })
                    .addOnFailureListener(e -> {
                        bgResult(reqId, "", "La IA aún no está lista. Si es la primera vez, deja el teléfono con internet 1-2 minutos y vuelve a intentar.");
                        closeQuietly(seg);
                    });
        } catch (Throwable t) {
            bgResult(reqId, "", "Error de IA: " + t.getMessage());
        }
    }

    private static void closeQuietly(SubjectSegmenter s) {
        try {
            s.close();
        } catch (Exception ignored) {
        }
    }

    private void bgResult(String id, String b64, String err) {
        js("window.__nativeBg && __nativeBg(" + JSONObject.quote(id) + "," + JSONObject.quote(b64)
                + "," + JSONObject.quote(err) + ")");
    }

    // ---------- Paquetes de stickers para WhatsApp ----------

    static File packsDir(android.content.Context c) {
        File d = new File(c.getFilesDir(), "packs");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static boolean safeId(String s) {
        return s != null && s.matches("[A-Za-z0-9_]{1,64}");
    }

    static boolean safeFile(String s) {
        return s != null && s.matches("[A-Za-z0-9_]{1,64}\\.(webp|png)");
    }

    static JSONObject readPack(File dir) {
        try {
            File f = new File(dir, "pack.json");
            if (!f.exists()) return null;
            byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
            return new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    static void writeBytes(File f, byte[] data) throws Exception {
        try (FileOutputStream fo = new FileOutputStream(f)) {
            fo.write(data);
        }
    }

    @JavascriptInterface
    public String packCreate(String name, String publisher, boolean animated) {
        try {
            String id = "pack_" + System.currentTimeMillis();
            File d = new File(packsDir(act), id);
            if (!d.mkdirs()) return "";
            JSONObject o = new JSONObject();
            o.put("name", trim(name, 120));
            o.put("publisher", trim(publisher, 120));
            o.put("animated", animated);
            o.put("version", String.valueOf(System.currentTimeMillis()));
            o.put("ready", false);
            o.put("stickers", new JSONArray());
            writeBytes(new File(d, "pack.json"), o.toString().getBytes(StandardCharsets.UTF_8));
            return id;
        } catch (Exception e) {
            return "";
        }
    }

    private static String trim(String s, int max) {
        if (s == null || s.trim().isEmpty()) return "StickerLab";
        s = s.trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    @JavascriptInterface
    public synchronized boolean packAddSticker(String id, String file, String emoji, String b64) {
        try {
            if (!safeId(id) || !safeFile(file)) return false;
            File d = new File(packsDir(act), id);
            JSONObject o = readPack(d);
            if (o == null) return false;
            writeBytes(new File(d, file), Base64.decode(b64, Base64.DEFAULT));
            JSONObject s = new JSONObject();
            s.put("file", file);
            s.put("emoji", (emoji == null || emoji.isEmpty()) ? "😀" : emoji);
            o.getJSONArray("stickers").put(s);
            writeBytes(new File(d, "pack.json"), o.toString().getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean packSetTray(String id, String b64) {
        try {
            if (!safeId(id)) return false;
            File d = new File(packsDir(act), id);
            if (!d.isDirectory()) return false;
            writeBytes(new File(d, "tray.png"), Base64.decode(b64, Base64.DEFAULT));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void packAddToWhatsApp(String id, String target) {
        try {
            if (!safeId(id)) return;
            File d = new File(packsDir(act), id);
            JSONObject o = readPack(d);
            if (o == null) return;
            o.put("ready", true);
            writeBytes(new File(d, "pack.json"), o.toString().getBytes(StandardCharsets.UTF_8));
            final String name = o.optString("name", "StickerLab");
            final String pkg = ("com.whatsapp".equals(target) || "com.whatsapp.w4b".equals(target)) ? target : "";
            act.runOnUiThread(() -> act.addPackToWhatsApp(id, name, pkg));
        } catch (Exception e) {
            toast("No se pudo preparar el paquete");
        }
    }
}
