package com.stickerlab.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/**
 * Expone los paquetes a WhatsApp con el formato oficial de stickers de terceros:
 *   content://<authority>/metadata
 *   content://<authority>/metadata/<pack_id>
 *   content://<authority>/stickers/<pack_id>
 *   content://<authority>/stickers_asset/<pack_id>/<archivo>
 */
public class StickerProvider extends ContentProvider {

    private static final int METADATA_ALL = 1;
    private static final int METADATA_ONE = 2;
    private static final int STICKERS = 3;
    private static final int ASSET = 4;

    private static final String[] META_COLUMNS = {
            "sticker_pack_identifier",
            "sticker_pack_name",
            "sticker_pack_publisher",
            "sticker_pack_icon",
            "android_play_store_link",
            "ios_app_download_link",
            "sticker_pack_publisher_email",
            "sticker_pack_publisher_website",
            "sticker_pack_privacy_policy_website",
            "sticker_pack_license_agreement_website",
            "image_data_version",
            "whatsapp_will_not_cache_stickers",
            "animated_sticker_pack"
    };

    private static final String[] STICKER_COLUMNS = {
            "sticker_file_name",
            "sticker_emoji",
            "sticker_accessibility_text"
    };

    private UriMatcher matcher;
    private String authority;

    @Override
    public boolean onCreate() {
        authority = getContext().getPackageName() + ".stickercontentprovider";
        matcher = new UriMatcher(UriMatcher.NO_MATCH);
        matcher.addURI(authority, "metadata", METADATA_ALL);
        matcher.addURI(authority, "metadata/*", METADATA_ONE);
        matcher.addURI(authority, "stickers/*", STICKERS);
        matcher.addURI(authority, "stickers_asset/*/*", ASSET);
        return true;
    }

    private File packDir(String id) {
        return new File(NativeBridge.packsDir(getContext()), id);
    }

    private void addMetaRow(MatrixCursor c, String id, JSONObject o) {
        c.addRow(new Object[]{
                id,
                o.optString("name", "StickerLab"),
                o.optString("publisher", "StickerLab"),
                "tray.png",
                "", "", "", "", "", "",
                o.optString("version", "1"),
                0,
                o.optBoolean("animated", false) ? 1 : 0
        });
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        int m = matcher.match(uri);
        if (m == METADATA_ALL) {
            MatrixCursor c = new MatrixCursor(META_COLUMNS);
            File[] dirs = NativeBridge.packsDir(getContext()).listFiles();
            if (dirs != null) {
                for (File d : dirs) {
                    JSONObject o = NativeBridge.readPack(d);
                    if (o != null && o.optBoolean("ready", false)) addMetaRow(c, d.getName(), o);
                }
            }
            c.setNotificationUri(getContext().getContentResolver(), uri);
            return c;
        }
        if (m == METADATA_ONE) {
            String id = uri.getLastPathSegment();
            MatrixCursor c = new MatrixCursor(META_COLUMNS);
            if (NativeBridge.safeId(id)) {
                JSONObject o = NativeBridge.readPack(packDir(id));
                if (o != null) addMetaRow(c, id, o);
            }
            c.setNotificationUri(getContext().getContentResolver(), uri);
            return c;
        }
        if (m == STICKERS) {
            String id = uri.getLastPathSegment();
            MatrixCursor c = new MatrixCursor(STICKER_COLUMNS);
            if (NativeBridge.safeId(id)) {
                JSONObject o = NativeBridge.readPack(packDir(id));
                JSONArray arr = o == null ? null : o.optJSONArray("stickers");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject s = arr.optJSONObject(i);
                        if (s == null) continue;
                        c.addRow(new Object[]{s.optString("file"), s.optString("emoji", "😀"), ""});
                    }
                }
            }
            c.setNotificationUri(getContext().getContentResolver(), uri);
            return c;
        }
        throw new IllegalArgumentException("URI desconocida: " + uri);
    }

    @Override
    public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws FileNotFoundException {
        if (matcher.match(uri) != ASSET) throw new FileNotFoundException(uri.toString());
        List<String> seg = uri.getPathSegments();
        if (seg.size() != 3) throw new FileNotFoundException(uri.toString());
        String id = seg.get(1);
        String file = seg.get(2);
        if (!NativeBridge.safeId(id) || !NativeBridge.safeFile(file)) throw new FileNotFoundException(uri.toString());
        File f = new File(packDir(id), file);
        if (!f.exists()) throw new FileNotFoundException(uri.toString());
        ParcelFileDescriptor pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        return new AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH);
    }

    @Override
    public String getType(Uri uri) {
        switch (matcher.match(uri)) {
            case METADATA_ALL:
                return "vnd.android.cursor.dir/vnd." + authority + ".metadata";
            case METADATA_ONE:
                return "vnd.android.cursor.item/vnd." + authority + ".metadata";
            case STICKERS:
                return "vnd.android.cursor.dir/vnd." + authority + ".stickers";
            case ASSET:
                String f = uri.getLastPathSegment();
                return f != null && f.endsWith(".png") ? "image/png" : "image/webp";
            default:
                throw new IllegalArgumentException("URI desconocida: " + uri);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Solo lectura");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Solo lectura");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Solo lectura");
    }
}
