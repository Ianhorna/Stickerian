# StickerLab (web + app Android) — 100 % gratis

Crea stickers de WhatsApp estáticos y animados, quita fondos con IA, añade texto y memes,
y añade paquetes directo a **WhatsApp** y **WhatsApp Business**.

## Cómo encaja todo
- **Web (gratis en GitHub Pages):** editor completo desde cualquier navegador. En Android, el botón
  **📤 Enviar paquete a la app StickerLab** manda tus stickers a la app.
- **App Android (APK gratis en GitHub Releases):** el mismo editor + IA para quitar fondos +
  botón **Añadir a WhatsApp / WhatsApp Business** (sistema oficial de paquetes).
- Una web sola no puede instalar paquetes en WhatsApp: WhatsApp solo los acepta desde una app instalada.

## Publicar todo gratis (una sola vez, ~10 minutos)
1. Crea una cuenta en github.com y un repositorio nuevo, por ejemplo `stickerlab`.
2. Sube **todo el contenido** de esta carpeta, incluida la carpeta oculta `.github`
   (desde PC: *Add file → Upload files* y arrastra todas las carpetas).
3. En el repositorio: **Settings → Pages → Source: GitHub Actions**.
4. Ve a **Actions → Compilar APK y publicar web → Run workflow** (o sube cualquier cambio).
5. En unos 5-8 minutos tendrás:
   - Web: `https://TU-USUARIO.github.io/stickerlab/`
   - APK: `https://github.com/TU-USUARIO/stickerlab/releases/latest/download/StickerLab.apk`

Esos dos enlaces son los que publicas en el foro. La web muestra sola el enlace de descarga de la APK.

## Instalar la APK
Abre el enlace en el teléfono → descarga → abre el archivo → permite "Instalar apps desconocidas" → Instalar.
Play Protect puede avisar porque no viene de Play Store; es normal en apps propias.
Funciona en Android 8 o superior (Galaxy S25 Ultra, S26 Ultra, etc.).

## Uso rápido
1. Crea un sticker → pestaña **Guardar → ➕ Al paquete**. Repite (de 3 a 30, todos estáticos o todos animados).
2. Elige **Destino: WhatsApp o WhatsApp Business** → **Añadir … a WhatsApp** → confirma en WhatsApp.
3. También puedes compartir imágenes o stickers .webp desde la galería o la web hacia **StickerLab**:
   los stickers 512×512 entran directo al paquete; las fotos se abren en el editor.

## Firma de la app
`app/stickerlab.jks` (contraseña `stickerlab123`) firma la APK. No la cambies ni la pierdas:
si cambia, las actualizaciones no se instalan encima. Si el repositorio es público, cualquiera
podría firmar una app con esa llave; para algo serio usa un repositorio privado (Pages en
repos privados requiere plan de pago, en ese caso publica la web desde otro repo público).
